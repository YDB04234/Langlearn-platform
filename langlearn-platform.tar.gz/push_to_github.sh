#!/bin/bash

# ===========================================
# 多语言学习平台 - GitHub 推送脚本
# ===========================================

echo "🚀 开始推送代码到 GitHub..."

# 1. 验证SSH连接
echo "📡 测试SSH连接..."
ssh -T git@github.com

# 2. 推送代码
echo "📤 推送代码到远程仓库..."
git push -u origin main

# 3. 验证推送结果
echo "✅ 推送完成！"
echo ""
echo "请访问 https://github.com/YDB04234/langlearn-platform 查看你的代码"
